package node;

import utils.Message;
import utils.MulticastManager;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class Node {
    private int nodeId;
    private int messageId = 0; // ID dell'ultimo messaggio inviato

    private MulticastManager multicastManager;

    // Server info
    private String serverAddress;
    private int serverPort;

    // Probabilità di perdita dei pacchetti (es. 20% di probabilità che un pacchetto venga perso)
    private static final double LP = 0.8;

    // Mappa per tenere traccia dei messaggi attesi dagli altri nodi (NodeID -> Next Expected MessageID)
    private Map<Integer, Integer> expectedMessages = new ConcurrentHashMap<>();

    // Mappa per salvare i messaggi inviati, utile per i reinvii (MessageID -> Message)
    private Map<Integer, Message> sentMessages = new ConcurrentHashMap<>();

    public Node(int nodeId, String multicastAddress, int multicastPort, String serverAddress, int serverPort) throws IOException {
        this.nodeId = nodeId;
        this.multicastManager = new MulticastManager(multicastAddress, multicastPort);
        this.serverAddress = serverAddress;
        this.serverPort = serverPort;
    }

    public void start() {
        // 1. Contatta il Server e aspetta il via 
        try (Socket serverSocket = new Socket(serverAddress, serverPort);
             BufferedReader in = new BufferedReader(new InputStreamReader(serverSocket.getInputStream()));
             PrintWriter out = new PrintWriter(serverSocket.getOutputStream(), true)) {

            System.out.println("⏳ Nodo " + nodeId + " connesso al server. In attesa del comando di avvio...");

            // Aspetta che il server invii un segnale (es. "START")
            String startCommand = in.readLine();
            System.out.println("🟢 Segnale ricevuto dal server: " + startCommand + ". Inizio comunicazioni!");

            // 2. Avvia il thread di ricezione
            Thread receiverThread = new Thread(this::receiveMessages);
            receiverThread.start();

            // 3. Avvia l'invio dei messaggi
            sendMessages();

            // 4. Comunica al server il completamento (raggiunto quota 100)
            out.println("DONE_" + nodeId);
            System.out.println("🏁 Nodo " + nodeId + " ha notificato il server del completamento.");

            // Opzionale: attendere che il thread di ricezione termini se il server chiude il sistema
            // receiverThread.join();

        } catch (IOException e) {
            System.err.println("❌ Errore di connessione al server: " + e.getMessage());
        }
    }

    private void sendMessages() {
        while (messageId < 100) { // Si ferma quando messageId è uguale a cento
            messageId++; // Incrementa l'ID
            try {
                // Crea e salva il messaggio per eventuali reinvii
                Message message = new Message(nodeId, messageId, Message.Type.DATA);
                sentMessages.put(messageId, message);

                //multicastManager.sendMessage(message); //old
                trySend(message);

                System.out.println("🔹 Nodo " + nodeId + " ha inviato: " + message);

                Thread.sleep(500); // Intervallo tra gli invii (regolabile)
            } catch (IOException | InterruptedException e) {
                e.printStackTrace();
            }
        }
        System.out.println("✅ Nodo " + nodeId + " ha completato l'invio dei suoi 100 messaggi.");
    }

    private void trySend(Message message) throws IOException {
        if (Math.random() > LP) {
            System.out.println("⚠️ Nodo " + nodeId + " PERDITA SIMULATA: " + message);
            return; // simula perdita
        }
        multicastManager.sendMessage(message);
    }

    private void receiveMessages() {
        while (true) {
            try {
                Message message = multicastManager.receiveMessage();

                int senderId = message.getNodeId();
                int msgId = message.getMessageId();
                Message.Type type = message.getType();

                // Ignora i propri messaggi (a meno che non ti serva per debugging)
                if (senderId == this.nodeId && type != Message.Type.LOSS_NOTIFICATION) {
                    continue;
                }

                switch (type) {
                    case DATA:
                    case RETRANSMIT:
                        handleIncomingData(senderId, msgId, type);
                        break;

                    case LOSS_NOTIFICATION:
                        handleLossNotification(senderId, msgId);
                        break;
                }

            } catch (IOException | ClassNotFoundException e) {
                System.err.println("Socket chiuso o errore in ricezione. Termino thread di ascolto.");
                break;
            }
        }
    }

    private void handleIncomingData(int senderId, int msgId, Message.Type type) throws IOException {
        // Se è la prima volta che sentiamo questo nodo, ci aspettiamo che parta da 1 o dall'ID corrente
        expectedMessages.putIfAbsent(senderId, 1);
        int expectedId = expectedMessages.get(senderId);

        if (msgId == expectedId) {
            // Messaggio ricevuto in ordine!
            System.out.println("📩 Nodo " + nodeId + " ha ricevuto: " + msgId + " dal Nodo " + senderId);
            expectedMessages.put(senderId, expectedId + 1); // Avanziamo l'attesa al prossimo
        }
        else if (msgId > expectedId) {
            // BUCO RILEVATO! Abbiamo ricevuto un ID maggiore del previsto
            System.out.println("⚠️ Nodo " + nodeId + " ha rilevato un buco! Atteso: " + expectedId + ", Ricevuto: " + msgId + " dal Nodo " + senderId);

            // Creiamo la notifica di perdita. Come concordato, mettiamo l'ID del nodo originale e l'ID perso
            Message lossNotification = new Message(senderId, expectedId, Message.Type.LOSS_NOTIFICATION);
            //multicastManager.sendMessage(lossNotification); //old
            trySend(lossNotification);
            System.out.println("📢 Nodo " + nodeId + " ha inviato LOSS_NOTIFICATION per msg " + expectedId + " del Nodo " + senderId);

            // NOTA: Non aggiorniamo l'expectedId qui. Aspettiamo che arrivi il RETRANSMIT per avanzare.
        }
        // Se msgId < expectedId, è un messaggio vecchio o un duplicato, lo ignoriamo.
    }

    private void handleLossNotification(int lostMsgNodeId, int lostMsgId) throws IOException {
        // Qualcuno ha perso un messaggio. Sono io il mittente originale?
        if (lostMsgNodeId == this.nodeId) {
            System.out.println("🆘 Nodo " + nodeId + " ha ricevuto richiesta di reinvio per il proprio messaggio " + lostMsgId);

            // Recupero il messaggio dalla memoria
            Message lostMessage = sentMessages.get(lostMsgId);
            if (lostMessage != null) {
                // Lo reinvio come RETRANSMIT. L'ID del messaggio non viene incrementato
                Message retransmitMsg = new Message(this.nodeId, lostMsgId, Message.Type.RETRANSMIT);
                //multicastManager.sendMessage(retransmitMsg);
                trySend(retransmitMsg);
                System.out.println("🔁 Nodo " + nodeId + " ha reinviato il messaggio " + lostMsgId);
            }
        }
    }

    public static void main(String[] args) {
        if (args.length < 1) {
            System.out.println("❌ Errore: Specificare l'ID del nodo come argomento.");
            return;
        }
        int nodeId = Integer.parseInt(args[0]);
        String multicastAddress = "230.0.0.0"; // Indirizzo IP di classe D per il multicast
        int multicastPort = 5000;

        String serverAddress = "127.0.0.1"; // Indirizzo del Server TCP
        int serverPort = 6000;              // Porta del Server TCP

        try {
            Node node = new Node(nodeId, multicastAddress, multicastPort, serverAddress, serverPort);
            node.start();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}