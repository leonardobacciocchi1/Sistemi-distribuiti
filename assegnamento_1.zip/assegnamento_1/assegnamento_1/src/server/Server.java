package server;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Server {
    // NOTA: Assicurati che questa porta corrisponda a quella configurata nella classe Node!
    private static final int PORT = 6000;

    private int totalNodes;
    private Set<Integer> completedNodes = new HashSet<>();
    private List<Socket> connectedNodes = new ArrayList<>();

    public Server(int totalNodes) {
        this.totalNodes = totalNodes;
    }

    public void start() {
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("🌍 Server avviato sulla porta " + PORT + ". In attesa di " + totalNodes + " nodi...");

            // FASE 1: Aspetta che tutti i nodi si connettano
            while (connectedNodes.size() < totalNodes) {
                Socket socket = serverSocket.accept();
                connectedNodes.add(socket);
                System.out.println("✅ Un nodo si è connesso. Totale pronti: " + connectedNodes.size() + "/" + totalNodes);
            }

            System.out.println("🚀 Tutti i nodi sono connessi! Invio segnale di START...");

            // FASE 2: Invia il segnale di inizio a tutti i nodi
            for (Socket socket : connectedNodes) {
                PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
                out.println("START");
            }

            // FASE 3: Attendi che i nodi comunichino il completamento (messaggio ID = 100)
            for (Socket socket : connectedNodes) {
                new Thread(() -> {
                    try {
                        BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                        String response = in.readLine(); // Si aspetta il formato "DONE_id"

                        if (response != null && response.startsWith("DONE_")) {
                            int nodeId = Integer.parseInt(response.split("_")[1]);

                            // Blocco sincronizzato per evitare problemi di concorrenza sull'HashSet
                            synchronized (completedNodes) {
                                completedNodes.add(nodeId);
                                System.out.println("🏁 Nodo " + nodeId + " ha completato (" + completedNodes.size() + "/" + totalNodes + ").");

                                // Se tutti hanno finito, il server chiude il sistema
                                if (completedNodes.size() == totalNodes) {
                                    System.out.println("🎉 Tutti i nodi hanno completato a quota 100! Il server chiude il sistema.");
                                    System.exit(0);
                                }
                            }
                        }
                    } catch (IOException e) {
                        System.err.println("Errore di comunicazione con un nodo.");
                    }
                }).start();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        if (args.length < 1) {
            System.out.println("❌ Errore: Specificare il numero totale di nodi.");
            return;
        }

        int totalNodes = Integer.parseInt(args[0]);
        Server server = new Server(totalNodes);
        server.start();
    }
}