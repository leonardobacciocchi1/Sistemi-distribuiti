@echo off
echo =========================================
echo Avvio del Sistema Distribuito Multicast
echo =========================================

:: Imposta il percorso esatto dove IntelliJ ha salvato i tuoi file compilati (.class)
set CLASSPATH="C:\Users\leona\Desktop\SD\assegnamento_1\assegnamento_1\out\production\assegnamento_1"

echo Avvio il Server (attende 3 nodi)...
start "Server" cmd /k "chcp 65001 > nul && java -cp %CLASSPATH% server.Server 3"

:: Attende 2 secondi per dare tempo al Server di mettersi in ascolto sulla porta TCP
timeout /t 2 /nobreak > NUL

echo Avvio il Nodo 1...
start "Nodo 1" cmd /k "chcp 65001 > nul && java -cp %CLASSPATH% node.Node 1"

echo Avvio il Nodo 2...
start "Nodo 2" cmd /k "chcp 65001 > nul && java -cp %CLASSPATH% node.Node 2"

echo Avvio il Nodo 3...
start "Nodo 3" cmd /k "chcp 65001 > nul && java -cp %CLASSPATH% node.Node 3"

echo Tutti i processi sono stati lanciati! Controlla le nuove finestre.
pause