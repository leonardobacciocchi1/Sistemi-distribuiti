// Cosa fa questa classe?
// Implementa Serializable per permettere l'invio del messaggio attraverso i socket.
// Contiene l'ID del nodo mittente e l'ID del messaggio.
// Ha un metodo toString() per stampare il messaggio in modo leggibile.

package utils;

import java.io.Serializable;

public class Message implements Serializable {

    public enum Type {
        DATA,               // Messaggio dati normale
        LOSS_NOTIFICATION,  // Notifica di perdita: "ho perso il msg X del nodo Y"
        RETRANSMIT          // Reinvio del messaggio perso
    }

    private final Type type;
    private int nodeId;  // ID del nodo mittente
    private int messageId;  // ID del messaggio


    public Message(Type type, int nodeId, int messageId) {
        this.type = type;
        this.nodeId = nodeId;
        this.messageId = messageId;
    }

    public Type getType(){ return type; }

    public int getNodeId() {
        return nodeId;
    }

    public int getMessageId() {
        return messageId;
    }

    @Override
    public String toString() {
        return "Message{type=" + type + ", sender=" + nodeId + ", msgId=" + messageId + "}";
    }
}

