package decentralized;

import common.*;

import java.util.*;
import java.util.concurrent.CountDownLatch;

/**
 * Decentralized Mutual Exclusion — Maekawa's Voting Algorithm (1985).
 *
 * Each node belongs to a "quorum" (voting set). A node may enter the CS
 * only after collecting a vote from every member of its quorum.
 *
 * This implementation uses a simplified voter logic (no RESCIND):
 *   - Voter sends VOTE to the first requester; queues the rest.
 *   - On VOTE_RELEASE the voter grants the next queued request.
 *
 * For N <= 7 every node is in every quorum (full quorum / unanimous voting).
 * For N > 7 a grid quorum (size ~sqrt(N)) is used.
 *
 * common.Message complexity: O(sqrt(N)) per CS entry with grid quorums.
 */
public class DecentralizedNode extends MutexNode {


    // ---------------------------------------------------------------
    // Stato del richiedente
    // ---------------------------------------------------------------
    private enum ReqState { RELEASED, WANTED, HELD }

    private final Object reqLock  = new Object();
    private ReqState     reqState = ReqState.RELEASED;
    private long         myTs     = 0;

    /** Quanti voti netti abbiamo raccolto in questo round. */
    private int          voteCount = 0;

    /** Quanti voti ci servono per entrare. */
    private int          votesNeeded = 0;

    /** Set dei voter che ci hanno già dato il voto (per gestire il rescind). */
    private final Set<Integer> votesReceived = new HashSet<>();

    // ---------------------------------------------------------------
    // Stato del voter
    // ---------------------------------------------------------------
    private final Object voterLock = new Object();

    private int     votedFor    = -1;
    private long    votedTs     = Long.MAX_VALUE;
    private boolean rescindSent = false;

    private final PriorityQueue<Message> voteQueue = new PriorityQueue<>(
            Comparator.comparingLong(Message::getTimestamp)
                    .thenComparingInt(Message::getSenderId));

    // ---------------------------------------------------------------
    private final List<Integer> quorum;
    private final int majority;

    public DecentralizedNode(int id, List<NodeInfo> peers) {
        super(id, peers);
        this.quorum   = buildQuorum(id, peers.size());
        this.majority = (peers.size() / 2) + 1;
        log("quorum = " + quorum + "  majority=" + majority);
    }

    // ---------------------------------------------------------------
    // API pubblica
    // ---------------------------------------------------------------

    @Override
    public void requestCS() throws InterruptedException {
        synchronized (reqLock) {
            myTs        = tickSend();
            reqState    = ReqState.WANTED;
            voteCount   = 0;
            votesNeeded = majority;
            votesReceived.clear();
        }

        log("broadcast VOTE_REQUEST (ts=" + myTs + ") al quorum " + quorum);
        for (int memberId : quorum) {
            sendTo(memberId, new Message(id, MessageType.VOTE_REQUEST, myTs));
        }

        // Aspetta finché voteCount == votesNeeded
        synchronized (reqLock) {
            while (voteCount < votesNeeded) {
                reqLock.wait();
            }
            reqState = ReqState.HELD;
        }
        log("tutti i voti raccolti — entro nella CS");
    }

    @Override
    public void releaseCS() {
        log("esco dalla CS — VOTE_RELEASE al quorum");
        synchronized (reqLock) { reqState = ReqState.RELEASED; }
        long ts = tickSend();
        for (int memberId : quorum) {
            sendTo(memberId, new Message(id, MessageType.VOTE_RELEASE, ts));
        }
    }

    // ---------------------------------------------------------------
    // Dispatcher
    // ---------------------------------------------------------------

    @Override
    protected void handleMessage(Message msg) {
        switch (msg.getType()) {
            case VOTE_REQUEST -> handleVoteRequest(msg);
            case VOTE         -> handleVote(msg);
            case RESCIND      -> handleRescind(msg);
            case VOTE_RELEASE -> handleVoteRelease(msg);
            default           -> log("messaggio inatteso: " + msg);
        }
    }

    // ---------------------------------------------------------------
    // Lato VOTER
    // ---------------------------------------------------------------

    private void handleVoteRequest(Message req) {
        log("VOTE_REQUEST da Node-" + req.getSenderId() + " (ts=" + req.getTimestamp() + ")");
        synchronized (voterLock) {
            if (votedFor < 0) {
                castVote(req.getSenderId(), req.getTimestamp());
            } else {
                boolean newHasPriority = req.getTimestamp() < votedTs
                        || (req.getTimestamp() == votedTs && req.getSenderId() < votedFor);

                if (newHasPriority && !rescindSent) {
                    log("RESCIND → Node-" + votedFor + " (priorità: Node-" + req.getSenderId() + ")");
                    rescindSent = true;
                    voteQueue.add(req);
                    sendTo(votedFor, new Message(id, MessageType.RESCIND, tickSend()));
                } else {
                    log("accodo Node-" + req.getSenderId());
                    voteQueue.add(req);
                }
            }
        }
    }

    private void handleVoteRelease(Message msg) {
        log("VOTE_RELEASE da Node-" + msg.getSenderId());
        synchronized (voterLock) {
            votedFor    = -1;
            votedTs     = Long.MAX_VALUE;
            rescindSent = false;
            grantNextInQueue();
        }
    }

    private void grantNextInQueue() {
        if (!voteQueue.isEmpty() && votedFor < 0) {
            Message next = voteQueue.poll();
            castVote(next.getSenderId(), next.getTimestamp());
        }
    }

    private void castVote(int targetId, long targetTs) {
        votedFor = targetId;
        votedTs  = targetTs;
        log("VOTE → Node-" + targetId);
        sendTo(targetId, new Message(id, MessageType.VOTE, tickSend()));
    }

    // ---------------------------------------------------------------
    // Lato RICHIEDENTE
    // ---------------------------------------------------------------

    private void handleVote(Message msg) {
        log("VOTE da Node-" + msg.getSenderId());
        synchronized (reqLock) {
            if (reqState != ReqState.WANTED) return;
            if (votesReceived.add(msg.getSenderId())) {
                voteCount++;
                reqLock.notifyAll();
            }
        }
    }

    private void handleRescind(Message msg) {
        log("RESCIND da Node-" + msg.getSenderId());
        synchronized (reqLock) {
            if (reqState == ReqState.HELD) {
                log("ignoro RESCIND (sono in CS)");
                return;
            }
            if (reqState == ReqState.WANTED && votesReceived.remove(msg.getSenderId())) {
                voteCount--;
                // Non serve notifyAll: non stiamo avanzando, stiamo retrocedendo
                log("restituisco voto a Node-" + msg.getSenderId());
                sendTo(msg.getSenderId(),
                        new Message(id, MessageType.VOTE_RELEASE, tickSend()));
            }
        }
    }

    // ---------------------------------------------------------------
    // Costruzione del quorum
    // ---------------------------------------------------------------

    private static List<Integer> buildQuorum(int nodeId, int n) {
        if (n <= 7) {
            List<Integer> q = new ArrayList<>();
            for (int i = 0; i < n; i++) q.add(i);
            return q;
        }
        int side = (int) Math.ceil(Math.sqrt(n));
        int row  = nodeId / side;
        int col  = nodeId % side;
        Set<Integer> set = new LinkedHashSet<>();
        for (int c = 0; c < side; c++) { int nd = row*side+c; if (nd < n) set.add(nd); }
        for (int r = 0; r < side; r++) { int nd = r*side+col; if (nd < n) set.add(nd); }
        return new ArrayList<>(set);
    }
}
