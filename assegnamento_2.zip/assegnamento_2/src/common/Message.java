package common;

import java.io.Serializable;

/**
 * Universal message exchanged between nodes via TCP.
 * All algorithms share this class; unused fields are left at their default.
 */
public class Message implements Serializable {

    private static final long serialVersionUID = 1L;

    /** Who sent this message. */
    private final int senderId;

    /** The type of this message (determines semantics). */
    private final MessageType type;

    /**
     * Logical (Lamport) timestamp at send time.
     * Used by: Distributed (Ricart-Agrawala), Decentralized.
     */
    private final long timestamp;

    /**
     * Extra integer payload – meaning depends on algorithm:
     *   Centralized   : unused (-1)
     *   Token Ring    : unused (-1)
     *   Distributed   : unused (-1)
     *   Decentralized : nodeId that this voter already voted for (in RESCIND)
     */
    private final int extra;

    // -----------------------------------------------------------------
    // Constructors
    // -----------------------------------------------------------------

    public Message(int senderId, MessageType type, long timestamp) {
        this(senderId, type, timestamp, -1);
    }

    public Message(int senderId, MessageType type, long timestamp, int extra) {
        this.senderId  = senderId;
        this.type      = type;
        this.timestamp = timestamp;
        this.extra     = extra;
    }

    // -----------------------------------------------------------------
    // Accessors
    // -----------------------------------------------------------------

    public int         getSenderId()  { return senderId;  }
    public MessageType getType()      { return type;      }
    public long        getTimestamp() { return timestamp; }
    public int         getExtra()     { return extra;     }

    @Override
    public String toString() {
        return String.format("[%s | from=%d | ts=%d%s]",
                type, senderId, timestamp,
                extra >= 0 ? " | extra=" + extra : "");
    }
}
