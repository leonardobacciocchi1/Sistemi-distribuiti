package common;

import java.io.IOException;
import java.net.*;
import java.util.List;

/**
 * Base class for every node in every mutual-exclusion algorithm.
 *
 * Responsibilities:
 *  - Starts a TCP server thread that accepts incoming connections and
 *    dispatches each received {@link Message} to {@link #handleMessage(Message)}.
 *  - Exposes {@link #requestCS()} and {@link #releaseCS()} as the public API
 *    that the demo/test code calls.
 *  - Maintains a Lamport logical clock.
 */
public abstract class MutexNode {

    protected final int            id;
    protected final List<NodeInfo> peers;   // all nodes, including self
    protected final NodeInfo self;

    /** Lamport logical clock. */
    protected long clock = 0;

    private ServerSocket serverSocket;
    private volatile boolean running = true;

    // -----------------------------------------------------------------
    // Constructor
    // -----------------------------------------------------------------

    protected MutexNode(int id, List<NodeInfo> peers) {
        this.id    = id;
        this.peers = peers;
        this.self  = peers.get(id);
    }

    // -----------------------------------------------------------------
    // Lifecycle
    // -----------------------------------------------------------------

    /**
     * Starts the listening server and calls {@link #onStart()}.
     */
    public void start() throws IOException {
        serverSocket = new ServerSocket(self.getPort());
        Thread listener = new Thread(this::listenLoop, "Listener-" + id);
        listener.setDaemon(true);
        listener.start();
        log("started, listening on port " + self.getPort());
        onStart();
    }

    /** Stop the server socket. */
    public void stop() {
        running = false;
        try { serverSocket.close(); } catch (IOException ignored) {}
        onStop();
        log("stopped");
    }

    // -----------------------------------------------------------------
    // Abstract interface – implemented by each algorithm
    // -----------------------------------------------------------------

    /** Called once after the server socket is open. */
    protected void onStart() {}

    /** Called when the node is shutting down. */
    protected void onStop() {}

    /**
     * Request entry to the Critical Section.
     * Blocks until permission is granted.
     */
    public abstract void requestCS() throws InterruptedException;

    /**
     * Release the Critical Section.
     * Must be called after {@link #requestCS()} once the CS work is done.
     */
    public abstract void releaseCS();

    /**
     * Handle an incoming message from another node.
     * Runs in the listener thread pool.
     */
    protected abstract void handleMessage(Message msg);

    // -----------------------------------------------------------------
    // Lamport clock helpers
    // -----------------------------------------------------------------

    /** Increment clock and return new value (for "send" events). */
    protected synchronized long tickSend() {
        return ++clock;
    }

    /** Update clock on receive: max(local, received) + 1. */
    protected synchronized void tickReceive(long received) {
        clock = Math.max(clock, received) + 1;
    }

    // -----------------------------------------------------------------
    // Sending helpers
    // -----------------------------------------------------------------

    /** Send a message to a specific peer. */
    protected void sendTo(int targetId, Message msg) {
        Network.send(peers.get(targetId), msg);
    }

    /** Broadcast a message to all peers except self. */
    protected void broadcast(Message msg) {
        for (NodeInfo peer : peers) {
            if (peer.getId() != id) {
                Network.send(peer, msg);
            }
        }
    }

    // -----------------------------------------------------------------
    // Internal: TCP listener loop
    // -----------------------------------------------------------------

    private void listenLoop() {
        while (running) {
            try {
                Socket socket = serverSocket.accept();
                Thread handler = new Thread(() -> {
                    try {
                        Message msg = Network.receive(socket);
                        tickReceive(msg.getTimestamp());
                        handleMessage(msg);
                    } catch (Exception e) {
                        if (running) {
                            System.err.println("[Node-" + id + "] receive error: " + e.getMessage());
                        }
                    } finally {
                        try { socket.close(); } catch (IOException ignored) {}
                    }
                }, "Handler-" + id);
                handler.setDaemon(true);
                handler.start();
            } catch (IOException e) {
                if (running) {
                    System.err.println("[Node-" + id + "] accept error: " + e.getMessage());
                }
            }
        }
    }

    // -----------------------------------------------------------------
    // Logging
    // -----------------------------------------------------------------

    protected void log(String msg) {
        System.out.printf("[Node-%d | ts=%3d] %s%n", id, clock, msg);
    }

    // -----------------------------------------------------------------
    // Accessors
    // -----------------------------------------------------------------

    public int getId() { return id; }
}
