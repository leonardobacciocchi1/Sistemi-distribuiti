package common;

import java.io.*;
import java.net.*;

/**
 * Low-level helpers for sending/receiving {@link Message} objects over TCP.
 *
 * Every send opens a fresh connection; this keeps things simple and avoids
 * managing persistent connections inside the algorithm logic.
 */
public class Network {

    /** Timeout (ms) for establishing an outbound connection. */
    private static final int CONNECT_TIMEOUT_MS = 3_000;

    /** How many times to retry a failed send before giving up. */
    private static final int MAX_RETRIES = 5;

    /** Delay between retries (ms). */
    private static final int RETRY_DELAY_MS = 200;

    // prevent instantiation
    private Network() {}

    // -----------------------------------------------------------------
    // Send
    // -----------------------------------------------------------------

    /**
     * Sends {@code msg} to the node described by {@code target}.
     * Retries up to {@value MAX_RETRIES} times on transient failures.
     */
    public static void send(NodeInfo target, Message msg) {
        int attempts = 0;
        while (attempts < MAX_RETRIES) {
            try (Socket socket = new Socket()) {
                socket.connect(
                        new InetSocketAddress(target.getHost(), target.getPort()),
                        CONNECT_TIMEOUT_MS);
                ObjectOutputStream out =
                        new ObjectOutputStream(socket.getOutputStream());
                out.writeObject(msg);
                out.flush();
                return; // success
            } catch (IOException e) {
                attempts++;
                if (attempts >= MAX_RETRIES) {
                    System.err.printf("[common.Network] ERROR: could not send %s to %s after %d attempts: %s%n",
                            msg.getType(), target, MAX_RETRIES, e.getMessage());
                } else {
                    sleep(RETRY_DELAY_MS);
                }
            }
        }
    }

    // -----------------------------------------------------------------
    // Receive (one message from an already-accepted Socket)
    // -----------------------------------------------------------------

    /**
     * Reads one {@link Message} from an already-accepted {@link Socket}.
     * The caller is responsible for closing the socket afterwards.
     */
    public static Message receive(Socket socket) throws IOException, ClassNotFoundException {
        ObjectInputStream in = new ObjectInputStream(socket.getInputStream());
        return (Message) in.readObject();
    }

    // -----------------------------------------------------------------
    // Utility
    // -----------------------------------------------------------------

    private static void sleep(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException ie) {
            Thread.currentThread().interrupt();
        }
    }
}
