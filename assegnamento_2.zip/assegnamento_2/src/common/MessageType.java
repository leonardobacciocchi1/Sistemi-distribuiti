package common;

/**
 * All message types used across all mutual exclusion algorithms.
 * Not every algorithm uses every type.
 */
public enum MessageType {

    // --- Centralized ---
    REQUEST,        // Node → Coordinator: request to enter CS
    GRANT,          // Coordinator → Node: permission granted
    RELEASE,        // Node → Coordinator: exiting CS

    // --- Token Ring ---
    TOKEN,          // Node → NextNode: pass the token

    // --- Distributed (Ricart-Agrawala) ---
    OK,             // Node → Node: reply/acknowledgment

    // --- Decentralized (voting) ---
    VOTE_REQUEST,   // Node → Voters: request a vote
    VOTE,           // Voter → Node: cast a vote
    RESCIND,        // Voter → Node: rescind previously cast vote
    VOTE_RELEASE    // Node → Voters: release all votes after CS
}
