package decentralized;

import common.*;

import java.util.*;
import java.util.concurrent.CountDownLatch;

/**
 * Decentralized Mutual Exclusion — Maekawa's Voting Algorithm (1985).
 *
 * Each node belongs to a "quorum" (voting set). A node may enter the CS
 * only after collecting a vote from every member of its quorum.
 *
 * This implementation uses a simplified voter logic (no RESCIND):
 *   - Voter sends VOTE to the first requester; queues the rest.
 *   - On VOTE_RELEASE the voter grants the next queued request.
 *
 * For N <= 7 every node is in every quorum (full quorum / unanimous voting).
 * For N > 7 a grid quorum (size ~sqrt(N)) is used.
 *
 * common.Message complexity: O(sqrt(N)) per CS entry with grid quorums.
 */
public class DecentralizedNode extends MutexNode {

    // ---- Requester state ----
    private enum ReqState { RELEASED, WANTED, HELD }

    private final Object reqLock = new Object();
    private ReqState reqState = ReqState.RELEASED;
    private volatile CountDownLatch voteLatch;

    // ---- Voter state ----
    private final Object voterLock = new Object();
    /** Id of node we voted for (-1 = free). */
    private int votedFor = -1;
    /** Pending requests waiting for our vote, ordered by (ts, id). */
    private final PriorityQueue<Message> voteQueue = new PriorityQueue<>(
            Comparator.comparingLong(Message::getTimestamp)
                      .thenComparingInt(Message::getSenderId));

    /** My quorum: the set of nodes I ask for a vote. */
    private final List<Integer> quorum;

    public DecentralizedNode(int id, List<NodeInfo> peers) {
        super(id, peers);
        this.quorum = buildQuorum(id, peers.size());
        log("quorum = " + quorum);
    }

    // -----------------------------------------------------------------
    // Public API
    // -----------------------------------------------------------------

    @Override
    public void requestCS() throws InterruptedException {
        synchronized (reqLock) {
            reqState  = ReqState.WANTED;
            voteLatch = new CountDownLatch(quorum.size());
        }
        long ts = tickSend();
        log("broadcasting VOTE_REQUEST (ts=" + ts + ") to quorum " + quorum);
        for (int memberId : quorum) {
            sendTo(memberId, new Message(id, MessageType.VOTE_REQUEST, ts));
        }
        voteLatch.await();
        synchronized (reqLock) { reqState = ReqState.HELD; }
        log("all votes collected -- entering CS");
    }

    @Override
    public void releaseCS() {
        log("exiting CS -- broadcasting VOTE_RELEASE");
        synchronized (reqLock) { reqState = ReqState.RELEASED; }
        long ts = tickSend();
        for (int memberId : quorum) {
            sendTo(memberId, new Message(id, MessageType.VOTE_RELEASE, ts));
        }
    }

    // -----------------------------------------------------------------
    // common.Message handler
    // -----------------------------------------------------------------

    @Override
    protected void handleMessage(Message msg) {
        switch (msg.getType()) {
            case VOTE_REQUEST -> handleVoteRequest(msg);
            case VOTE         -> handleVote(msg);
            case VOTE_RELEASE -> handleVoteRelease(msg);
            default           -> log("unexpected message: " + msg);
        }
    }

    // -----------------------------------------------------------------
    // Voter logic
    // -----------------------------------------------------------------

    private void handleVoteRequest(Message req) {
        log("received VOTE_REQUEST from Node-" + req.getSenderId()
                + " (ts=" + req.getTimestamp() + ")");
        synchronized (voterLock) {
            if (votedFor < 0) {
                castVote(req.getSenderId());
            } else {
                log("queuing VOTE_REQUEST from Node-" + req.getSenderId()
                        + " (currently voted for Node-" + votedFor + ")");
                voteQueue.add(req);
            }
        }
    }

    private void handleVoteRelease(Message msg) {
        log("received VOTE_RELEASE from Node-" + msg.getSenderId());
        synchronized (voterLock) {
            votedFor = -1;
            if (!voteQueue.isEmpty()) {
                Message next = voteQueue.poll();
                castVote(next.getSenderId());
            }
        }
    }

    private void castVote(int targetId) {
        // Must be called while holding voterLock
        votedFor = targetId;
        log("casting VOTE for Node-" + targetId);
        sendTo(targetId, new Message(id, MessageType.VOTE, tickSend()));
    }

    // -----------------------------------------------------------------
    // Requester logic
    // -----------------------------------------------------------------

    private void handleVote(Message msg) {
        log("received VOTE from Node-" + msg.getSenderId());
        CountDownLatch latch = voteLatch;
        if (latch != null) latch.countDown();
    }

    // -----------------------------------------------------------------
    // Quorum construction
    // -----------------------------------------------------------------

    private static List<Integer> buildQuorum(int nodeId, int n) {
        if (n <= 7) {
            // Full quorum: everyone votes
            List<Integer> q = new ArrayList<>();
            for (int i = 0; i < n; i++) q.add(i);
            return q;
        }
        // Grid quorum: row(nodeId) union col(nodeId)
        int side = (int) Math.ceil(Math.sqrt(n));
        int row  = nodeId / side;
        int col  = nodeId % side;
        Set<Integer> set = new LinkedHashSet<>();
        for (int c = 0; c < side; c++) { int nd = row * side + c; if (nd < n) set.add(nd); }
        for (int r = 0; r < side; r++) { int nd = r   * side + col; if (nd < n) set.add(nd); }
        return new ArrayList<>(set);
    }
}
