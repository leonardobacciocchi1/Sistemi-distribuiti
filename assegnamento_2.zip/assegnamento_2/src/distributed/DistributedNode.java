package distributed;

import common.*;

import java.util.*;
import java.util.concurrent.CountDownLatch;

/**
 * Distributed Mutual Exclusion — Ricart & Agrawala (1981).
 *
 * No coordinator. Each node requests permission from ALL other nodes.
 * Uses Lamport timestamps to break ties.
 *
 * Algorithm (requestCS):
 *   1. Increment own sequence number; record (seqNum, id) as myRequest.
 *   2. Broadcast REQUEST to all other nodes.
 *   3. Wait for OK from every other node.
 *
 * Algorithm (on receiving REQUEST from j):
 *   - If NOT wanting CS -> reply OK immediately.
 *   - If HELD -> defer.
 *   - If WANTED -> compare (mySeq, myId) vs (theirSeq, theirId):
 *       if mine is smaller (higher priority) -> defer; else reply OK.
 *
 * Tie-breaking: lower (seqNum, nodeId) wins.
 * common.Message complexity: 2*(N-1) per CS entry.
 */
public class DistributedNode extends MutexNode {

    private enum State { RELEASED, WANTED, HELD }

    private final Object stateLock = new Object();

    private State   state      = State.RELEASED;
    private long    mySeq      = 0;
    private long    seqCounter = 0;

    private final List<Integer>     deferred = new ArrayList<>();
    private volatile CountDownLatch okLatch;

    public DistributedNode(int id, List<NodeInfo> peers) {
        super(id, peers);
    }

    @Override
    public void requestCS() throws InterruptedException {
        int others = peers.size() - 1;
        synchronized (stateLock) {
            seqCounter++;
            mySeq  = seqCounter;
            state  = State.WANTED;
            okLatch = new CountDownLatch(others);
        }
        log("broadcasting REQUEST (seq=" + mySeq + ")");
        broadcast(new Message(id, MessageType.REQUEST, mySeq));
        okLatch.await();
        synchronized (stateLock) { state = State.HELD; }
        log("all OKs received -- entering CS");
    }

    @Override
    public void releaseCS() {
        log("exiting CS -- sending deferred OKs");
        List<Integer> toNotify;
        synchronized (stateLock) {
            state    = State.RELEASED;
            toNotify = new ArrayList<>(deferred);
            deferred.clear();
        }
        long ts = tickSend();
        for (int nodeId : toNotify) {
            log("sending deferred OK to Node-" + nodeId);
            sendTo(nodeId, new Message(id, MessageType.OK, ts));
        }
    }

    @Override
    protected void handleMessage(Message msg) {
        switch (msg.getType()) {
            case REQUEST -> {
                long theirSeq = msg.getTimestamp();
                int  theirId  = msg.getSenderId();
                log("received REQUEST from Node-" + theirId + " (seq=" + theirSeq + ")");
                boolean sendOkNow;
                synchronized (stateLock) {
                    if (state == State.HELD) {
                        sendOkNow = false;
                    } else if (state == State.RELEASED) {
                        sendOkNow = true;
                    } else { // WANTED
                        boolean iHavePriority = (mySeq < theirSeq)
                                || (mySeq == theirSeq && id < theirId);
                        sendOkNow = !iHavePriority;
                    }
                    if (!sendOkNow) {
                        deferred.add(theirId);
                        log("deferring OK to Node-" + theirId);
                    }
                }
                if (sendOkNow) {
                    sendTo(theirId, new Message(id, MessageType.OK, tickSend()));
                }
            }
            case OK -> {
                log("received OK from Node-" + msg.getSenderId());
                CountDownLatch latch = okLatch;
                if (latch != null) latch.countDown();
            }
            default -> log("unexpected message: " + msg);
        }
    }
}
