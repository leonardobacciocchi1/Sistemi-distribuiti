package centralized;

import common.*;

import java.util.*;

/**
 * Centralized Mutual Exclusion — Coordinator.
 *
 * The coordinator receives REQUEST messages from all nodes, grants access
 * to one node at a time, and queues the rest.
 *
 * Algorithm:
 *   - On REQUEST  → if CS free: send GRANT immediately; else enqueue.
 *   - On RELEASE  → if queue non-empty: dequeue and send GRANT; else mark CS free.
 *
 * common.Message complexity: 3 messages per CS entry (REQUEST + GRANT + RELEASE).
 * Single point of failure: yes (coordinator).
 */
public class CentralizedCoordinator extends MutexNode {

    private boolean                    csOccupied = false;
    private final Queue<Integer>       waitQueue  = new LinkedList<>();
    private final Object               lock       = new Object();

    public CentralizedCoordinator(int id, List<NodeInfo> peers) {
        super(id, peers);
    }

    // The coordinator never enters the CS itself in this role.
    @Override public void requestCS() { throw new UnsupportedOperationException("Coordinator does not use CS"); }
    @Override public void releaseCS() { throw new UnsupportedOperationException("Coordinator does not use CS"); }

    @Override
    protected void handleMessage(Message msg) {
        switch (msg.getType()) {

            case REQUEST -> {
                log("received REQUEST from Node-" + msg.getSenderId());
                synchronized (lock) {
                    if (!csOccupied) {
                        csOccupied = true;
                        grantTo(msg.getSenderId());
                    } else {
                        waitQueue.add(msg.getSenderId());
                        log("Node-" + msg.getSenderId() + " queued (queue size=" + waitQueue.size() + ")");
                    }
                }
            }

            case RELEASE -> {
                log("received RELEASE from Node-" + msg.getSenderId());
                synchronized (lock) {
                    if (!waitQueue.isEmpty()) {
                        int next = waitQueue.poll();
                        grantTo(next);
                    } else {
                        csOccupied = false;
                        log("CS is now free");
                    }
                }
            }

            default -> log("unexpected message: " + msg);
        }
    }

    private void grantTo(int nodeId) {
        log("granting CS to Node-" + nodeId);
        long ts = tickSend();
        sendTo(nodeId, new Message(id, MessageType.GRANT, ts));
    }
}
