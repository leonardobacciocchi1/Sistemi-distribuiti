package centralized;

import common.*;

import java.util.List;
import java.util.concurrent.CountDownLatch;

/**
 * Centralized Mutual Exclusion — Worker node.
 *
 * Sends REQUEST to the coordinator and blocks until GRANT arrives.
 * After the CS, sends RELEASE to the coordinator.
 */
public class CentralizedWorker extends MutexNode {

    /** Id of the coordinator node (index in the peers list). */
    private final int coordinatorId;

    /** Latch released when GRANT arrives. */
    private volatile CountDownLatch grantLatch;

    public CentralizedWorker(int id, List<NodeInfo> peers, int coordinatorId) {
        super(id, peers);
        this.coordinatorId = coordinatorId;
    }

    // -----------------------------------------------------------------
    // Public API
    // -----------------------------------------------------------------

    @Override
    public void requestCS() throws InterruptedException {
        grantLatch = new CountDownLatch(1);
        long ts = tickSend();
        log("sending REQUEST to coordinator (Node-" + coordinatorId + ")");
        sendTo(coordinatorId, new Message(id, MessageType.REQUEST, ts));
        grantLatch.await();   // block until GRANT received
        log("GRANT received — entering CS");
    }

    @Override
    public void releaseCS() {
        log("exiting CS — sending RELEASE to coordinator");
        long ts = tickSend();
        sendTo(coordinatorId, new Message(id, MessageType.RELEASE, ts));
    }

    // -----------------------------------------------------------------
    // common.Message handler
    // -----------------------------------------------------------------

    @Override
    protected void handleMessage(Message msg) {
        if (msg.getType() == MessageType.GRANT) {
            log("received GRANT from coordinator");
            if (grantLatch != null) grantLatch.countDown();
        } else {
            log("unexpected message: " + msg);
        }
    }
}
