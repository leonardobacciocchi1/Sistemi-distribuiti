package tokenring;

import common.*;

import java.util.List;
import java.util.concurrent.CountDownLatch;

/**
 * Token Ring Mutual Exclusion.
 *
 * Nodes are arranged in a logical ring: 0 → 1 → 2 → … → N-1 → 0.
 * A single TOKEN circulates continuously.
 *
 * Algorithm:
 *   - When a node receives the TOKEN and does NOT want the CS:
 *       forward the token to the next node immediately.
 *   - When a node receives the TOKEN and WANTS the CS:
 *       enter CS, do work, exit CS, then forward the token.
 *
 * common.Message complexity: between 1 (always wanting CS) and N (never wanting CS)
 *                     messages per CS entry.
 * No starvation: guaranteed FIFO ordering by ring position.
 */
public class TokenRingNode extends MutexNode {

    private final int nextId;           // id of next node in the ring

    /** Set to true by requestCS(); cleared by releaseCS(). */
    private volatile boolean wantsCS = false;

    /** Latch released when the token arrives while wantsCS==true. */
    private volatile CountDownLatch tokenLatch;

    public TokenRingNode(int id, List<NodeInfo> peers) {
        super(id, peers);
        this.nextId = (id + 1) % peers.size();
    }

    // -----------------------------------------------------------------
    // Lifecycle
    // -----------------------------------------------------------------

    @Override
    protected void onStart() {
        // Node-0 holds the token at startup
        if (id == 0) {
            new Thread(() -> {
                sleep(300); // let all nodes start their servers
                log("I hold the initial token — forwarding");
                forwardToken();
            }, "TokenInit-0").start();
        }
    }

    // -----------------------------------------------------------------
    // Public API
    // -----------------------------------------------------------------

    @Override
    public void requestCS() throws InterruptedException {
        log("wants CS — waiting for token");
        tokenLatch = new CountDownLatch(1);
        wantsCS = true;
        tokenLatch.await();   // block until handleMessage releases it
        log("token received — entering CS");
    }

    @Override
    public void releaseCS() {
        log("exiting CS — forwarding token to Node-" + nextId);
        wantsCS = false;
        forwardToken();
    }

    // -----------------------------------------------------------------
    // common.Message handler
    // -----------------------------------------------------------------

    @Override
    protected void handleMessage(Message msg) {
        if (msg.getType() != MessageType.TOKEN) {
            log("unexpected message: " + msg);
            return;
        }

        log("received TOKEN from Node-" + msg.getSenderId());

        if (wantsCS) {
            // Signal requestCS() to proceed
            tokenLatch.countDown();
            // releaseCS() will forward the token after CS work is done
        } else {
            // Not interested — pass it on
            forwardToken();
        }
    }

    // -----------------------------------------------------------------
    // Helpers
    // -----------------------------------------------------------------

    private void forwardToken() {
        long ts = tickSend();
        sendTo(nextId, new Message(id, MessageType.TOKEN, ts));
        log("TOKEN forwarded to Node-" + nextId);
    }

    private static void sleep(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException ie) {
            Thread.currentThread().interrupt();
        }
    }
}
