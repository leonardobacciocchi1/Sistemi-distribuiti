package demo;

import centralized.*;
import common.*;
import decentralized.DecentralizedNode;
import distributed.DistributedNode;
import tokenring.TokenRingNode;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Automatic demo that runs each of the four mutual-exclusion algorithms
 * with N nodes, each attempting to enter the Critical Section.
 *
 * Each "CS entry" is simulated by sleeping for CS_WORK_MS milliseconds and
 * incrementing a shared counter.  Correctness is verified: the counter must
 * reach exactly N * CS_ENTRIES at the end, with no concurrent access.
 *
 * Run:  javac -d out -sourcepath src/main/java src/main/java/mutex/demo/demo.MutexDemo.java
 *       java  -cp out demo.demo.MutexDemo
 */
public class MutexDemo {

    // ---- Configuration ----
    static final int N            = 4;    // number of nodes
    static final int CS_ENTRIES   = 2;    // each node enters CS this many times
    static final int CS_WORK_MS   = 150;  // simulated CS work duration
    static final int BASE_PORT    = 9100; // ports BASE_PORT … BASE_PORT+N-1

    /** Shared counter — must only be incremented inside CS. */
    private static final AtomicInteger sharedCounter = new AtomicInteger(0);
    /** Detects concurrent CS violations. */
    private static volatile boolean    csViolation   = false;
    private static volatile int        inCS          = 0;

    // -----------------------------------------------------------------
    // Entry point
    // -----------------------------------------------------------------

    public static void main(String[] args) throws Exception {
        banner("MUTUAL EXCLUSION ALGORITHMS — DEMO");

        runAlgorithm("CENTRALIZZATO",   MutexDemo::runCentralized);
        runAlgorithm("TOKEN RING",      MutexDemo::runTokenRing);
        runAlgorithm("DISTRIBUITO (Ricart-Agrawala)", MutexDemo::runDistributed);
        runAlgorithm("DECENTRALIZZATO (Maekawa)",     MutexDemo::runDecentralized);

        System.out.println("\n" + "═".repeat(60));
        System.out.println("  ALL ALGORITHMS COMPLETED");
        System.out.println("═".repeat(60));
    }

    // -----------------------------------------------------------------
    // Algorithm runners
    // -----------------------------------------------------------------

    static void runCentralized() throws Exception {
        // Node-0 is the coordinator; nodes 1..N are workers.
        int totalNodes = N + 1;
        List<NodeInfo> peers = buildPeers(totalNodes, BASE_PORT);
        int coordId = 0;

        // Start coordinator
        CentralizedCoordinator coord = new CentralizedCoordinator(coordId, peers);
        coord.start();
        sleep(200);

        // Start workers
        List<CentralizedWorker> workers = new ArrayList<>();
        for (int i = 1; i <= N; i++) {
            CentralizedWorker w = new CentralizedWorker(i, peers, coordId);
            w.start();
            workers.add(w);
        }
        sleep(300);

        // Simulate CS entries
        runCSScenario(new ArrayList<>(workers));

        // Shutdown
        for (CentralizedWorker w : workers) w.stop();
        coord.stop();
    }

    static void runTokenRing() throws Exception {
        List<NodeInfo> peers = buildPeers(N, BASE_PORT + 20);

        List<TokenRingNode> nodes = new ArrayList<>();
        for (int i = 0; i < N; i++) {
            nodes.add(new TokenRingNode(i, peers));
        }
        for (TokenRingNode n : nodes) n.start();
        sleep(500); // let token start circulating

        runCSScenario(new ArrayList<>(nodes));

        for (TokenRingNode n : nodes) n.stop();
    }

    static void runDistributed() throws Exception {
        List<NodeInfo> peers = buildPeers(N, BASE_PORT + 40);

        List<DistributedNode> nodes = new ArrayList<>();
        for (int i = 0; i < N; i++) nodes.add(new DistributedNode(i, peers));
        for (DistributedNode n : nodes) n.start();
        sleep(300);

        runCSScenario(new ArrayList<>(nodes));

        for (DistributedNode n : nodes) n.stop();
    }

    static void runDecentralized() throws Exception {
        List<NodeInfo> peers = buildPeers(N, BASE_PORT + 60);

        List<DecentralizedNode> nodes = new ArrayList<>();
        for (int i = 0; i < N; i++) nodes.add(new DecentralizedNode(i, peers));
        for (DecentralizedNode n : nodes) n.start();
        sleep(300);

        runCSScenario(new ArrayList<>(nodes));

        for (DecentralizedNode n : nodes) n.stop();
    }

    // -----------------------------------------------------------------
    // Generic CS scenario
    // -----------------------------------------------------------------

    /**
     * Each node in {@code nodes} attempts to enter the CS {@value CS_ENTRIES}
     * times concurrently.  Verifies mutual exclusion and counts messages.
     */
    @SuppressWarnings("unchecked")
    static void runCSScenario(List<? extends MutexNode> nodes) throws InterruptedException {
        sharedCounter.set(0);
        csViolation = false;
        inCS = 0;

        int total = nodes.size() * CS_ENTRIES;
        CountDownLatch done = new CountDownLatch(total);
        ExecutorService pool = Executors.newFixedThreadPool(nodes.size());

        for (MutexNode node : nodes) {
            pool.submit(() -> {
                for (int i = 0; i < CS_ENTRIES; i++) {
                    try {
                        node.requestCS();

                        // --- Critical Section ---
                        synchronized (MutexDemo.class) {
                            inCS++;
                            if (inCS > 1) {
                                csViolation = true;
                                System.err.println("!!! MUTUAL EXCLUSION VIOLATED — "
                                        + inCS + " nodes in CS simultaneously !!!");
                            }
                        }

                        int val = sharedCounter.incrementAndGet();
                        System.out.printf("  *** Node-%d IN CS  (counter=%d) ***%n",
                                node.getId(), val);
                        sleep(CS_WORK_MS);

                        synchronized (MutexDemo.class) { inCS--; }
                        // --- End of Critical Section ---

                        node.releaseCS();
                        done.countDown();

                        sleep(50 + (long)(Math.random() * 100)); // random think time
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                    }
                }
            });
        }

        pool.shutdown();
        boolean finished = done.await(60, TimeUnit.SECONDS);

        if (!finished)       System.err.println("  [WARN] Timeout — some CS entries did not complete");
        if (csViolation)     System.err.println("  [FAIL] MUTUAL EXCLUSION VIOLATED");
        else                 System.out.println("  [OK]   Mutual exclusion maintained");

        int expected = nodes.size() * CS_ENTRIES;
        int actual   = sharedCounter.get();
        if (actual != expected)
            System.err.printf("  [FAIL] Counter mismatch: expected=%d, got=%d%n", expected, actual);
        else
            System.out.printf("  [OK]   Counter correct: %d/%d%n", actual, expected);
    }

    // -----------------------------------------------------------------
    // Utilities
    // -----------------------------------------------------------------

    static List<NodeInfo> buildPeers(int n, int basePort) {
        List<NodeInfo> peers = new ArrayList<>();
        for (int i = 0; i < n; i++) peers.add(new NodeInfo(i, "127.0.0.1", basePort + i));
        return peers;
    }

    static void sleep(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException ie) {
            Thread.currentThread().interrupt();
        }
    }

    @FunctionalInterface interface ThrowingRunnable {
        void run() throws Exception;
    }

    static void runAlgorithm(String name, ThrowingRunnable algo) {
        System.out.println("\n" + "─".repeat(60));
        System.out.println("  ALGORITHM: " + name);
        System.out.println("  Nodes: " + N + " | CS entries per node: " + CS_ENTRIES);
        System.out.println("─".repeat(60));
        try {
            algo.run();
        } catch (Exception e) {
            System.err.println("  [ERROR] " + e.getMessage());
            e.printStackTrace();
        }
        sleep(500); // let sockets fully close between runs
    }

    static void banner(String text) {
        System.out.println("═".repeat(60));
        System.out.println("  " + text);
        System.out.println("═".repeat(60));
    }
}
